def create_keybinding():
    """
    Returns a key object based on a dictionary
    """