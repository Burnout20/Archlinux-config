#!/usr/bin/env bash

playerctl play-pause

