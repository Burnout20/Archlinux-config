#!/usr/bin/env python
# -*- coding: utf-8 -*-


# You can define a letter and its icon here
group_icons = ["B   ",
               "D  ",
               "T  ",
               "V  ",
               "M  ",
               "C  ",
               "E  ",
               "N  ",
               ]

